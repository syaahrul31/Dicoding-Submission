Feature('Favorite Resto');

Before(({ I }) => {
  I.amOnPage('/#/favorite');
  });

Scenario('Show Empty Like', ({ I }) => {
  I.amOnPage('/#/favorite');
  I.waitForElement('.not_found', 7);
  I.seeElement('.not_found');
});

Scenario('Like & Unlike Resto', ({ I }) => {
  I.amOnPage('/');
  I.waitForElement('#card', 7);
  I.seeElement('#card');

  const firstResto = locate('#card').first();
  I.click(firstResto);

  I.waitForElement('#likeButton', 7);
  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.waitForElement('#home', 3);
  I.amOnPage('/#/favorite');
  
  I.waitForElement('#card', 7);
  I.seeElement('#card');
  I.click(firstResto);

  I.waitForElement('#likeButton', 7);
  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/favorite');
  I.seeElement('.not_found');
});

