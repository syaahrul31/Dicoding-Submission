const CONFIG = {
  KEY: '11111',
  BASE_URL: 'https://restaurant-api.dicoding.dev/',
  BASE_IMAGE_URL: 'https://restaurant-api.dicoding.dev/images/large/',
  SMALL_IMAGE_URL: 'https://restaurant-api.dicoding.dev/images/small/',
  DEFAULT_LANGUAGE: 'en-us',
  CACHE_NAME: 'SifutResto-V1',
  DATABASE_NAME: 'sifut-resto-db',
  DATABASE_VERSION: 1,
  OBJECT_STORE_NAME: 'restaurants',
  WEB_SOCKET_SERVER: 'wss://javascript.info/article/websocket/chat/ws',
};

export default CONFIG;
